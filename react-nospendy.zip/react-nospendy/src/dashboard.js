import React from "react";
import { useNavigate } from "react-router-dom";
import "./dashboard.css";

const Dashboard = () => {
    const navigate = useNavigate();
    const handleSpendingHistoryClick = () => {
        navigate('/spendinghistory');
    }
    const handleLogExpensesClick = () => {
        navigate('/expenses');
        };

    return (
    <div className="dashboard">
        {/* ========== SIDEBAR ========== */}
        <aside className="sidebar">
            <div className="sidebar__brand">
                <h2>NoSpendy</h2>
            </div>
            <div className="sidebar__menu">
                <p className="sidebar__title">MANAGE</p>
                <ul>
                    <li className="active">Dashboard</li>
                    <li onClick={handleSpendingHistoryClick}> Spending History</li>
                    <li onClick={handleLogExpensesClick}>Log Expenses</li>
                    <li>Challenges</li>
                    <li>Leaderboard</li>
                    <li>Financial Overview</li>
                    <li>Notifications</li>
                    <li>Settings</li>
                    <li>Security</li>
                </ul>
            </div>
        </aside>
            {/* ========== MAIN CONTENT ========== */}
            <main className="main-content">
              {/* ========== TOP BAR ========== */}
                <header className="topbar">
                    <h1>Dashboard</h1>
                    <div className="topbar__search">
                        <input type="text" placeholder="Search" />
                        <button className="profile-btn">
                    <img
                        src="profile_icon.png"
                        alt="Profile"
                        className="profile-img"/>
                        </button>
                    </div>
                </header>
              {/* ========== CARDS (TOP STATS) ========== */}
                <section className="top-stats">
                        <div className="stat-card">
                        <h3>Total Expenses</h3>
                        <p className="stat-amount">$31,140.74</p>
                        </div>
                        <div className="stat-card">
                            <h3>Spending Challenge</h3>
                            <p className="stat-amount">$3,000.00</p>
                        </div>
                        <div className="stat-card">
                            <h3>Spent This Month</h3>
                            <p className="stat-amount">$500.00</p>
                        </div>
                        <div className="stat-card">
                            <h3>Streak</h3>
                            <p className="stat-amount">21 Days </p>
                        </div>
                </section>
              {/* ========== OVERVIEW & COMPARISON ========== */}
                <section className="overview">
                <div className="overview__chart">
                    <div className="chart-container">
                    <img src="/weekly_chart.png" alt="Weekly Chart" className="chart-image" />
                    </div>
                </div>
                </section>
              {/* ========== LEADERBOARD ========== */}
                <section className="leaderboard">
                <h2>Leaderboard</h2>
                <table>
                <thead>
                    <tr>
                    <th>Name</th>
                    <th>State</th>
                    <th>Monthly Expenses</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Mai Tran</td>
                        <td>New York</td>
                        <td>$404.21</td>
                    </tr>
                    <tr>
                        <td>Matthew Ding</td>
                        <td>New Jersey</td>
                        <td>$551.21</td>
                    </tr>
                    <tr>
                        <td>Yecheng Yue</td>
                        <td>New York</td>
                        <td>$674.90</td>
                    </tr>
                    </tbody>
                </table>
            </section>
            </main>
        </div>
    );
}

export default Dashboard;
