import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./expenses.css";

const Expenses = () => {
  const navigate = useNavigate();
  const [expenses, setExpenses] = useState({
    food: "",
    transportation: "",
    entertainment: "",
    essentials: "",
  });

  const handleChange = (e) => {
    setExpenses({ ...expenses, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Expense Data:", expenses);
    alert("Expense added successfully!");
    navigate("/dashboard");
  };

  return (
    <div className="log-expenses">
      <header>
        <h1>Log Expenses</h1>
      </header>
      <form onSubmit={handleSubmit}>
        <label>Food: $</label>
        <input type="text" name="food" value={expenses.food} onChange={handleChange} />
        
        <label>Transportation: $</label>
        <input type="text" name="transportation" value={expenses.transportation} onChange={handleChange} />
        
        <label>Entertainment: $</label>
        <input type="text" name="entertainment" value={expenses.entertainment} onChange={handleChange} />
        
        <label>Essentials: $</label>
        <input type="text" name="essentials" value={expenses.essentials} onChange={handleChange} />

        <button type="submit">Add Expense</button>

      </form>
    </div>
  );
};

export default Expenses;
