import './App.css';
import React from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import Signin from "./signin"
import Dashboard from "./dashboard";
import Expenses from "./expenses";
import Spendinghistory from "./spendinghistory"
import Createprofile from "./createprofile"


function App() {
  return (
    <Router>
      <Routes>
        {/* Default Route ("/") Redirects to SignIn */}
        <Route path="/" element={<Navigate to="/signin" />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/expenses" element={<Expenses />} />
        <Route path="/createprofile" element={<Createprofile />} />
        <Route path="/spendinghistory" element={<Spendinghistory />} />
      </Routes>
    </Router>
  );
}
export default App;
